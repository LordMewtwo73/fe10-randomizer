Thanks for downloading LordMewtwo's FE10 Randomizer!
This document will walk you through the randomization process step-by-step.
If you are a more visual learner, check out this youtube tutorial by Phi, thanks Phi!
https://www.youtube.com/watch?v=eofG_bdEh9k


1. Obtain an US ISO of FE10. I cannot tell you how to do this, but I would recommend
making a backup of the non-randomized ISO once you've found it. Randomizer is not tested
with PAL ISO, so US is recommended if not required

2. Extract the ISO to somewhere on your computer. I recommend using WiiBaFu, 
which can be found online easily.

3. Move "FE10Data.cms.decompressed" from the "tools" folder to the extracted DATA/files
This file is slightly different from the base game Data file, and this step is only necessary
if you are randomizing recruitment and/or classes, though the changes are helpful regardless.
What changes are made can be found in ChangesToGame.txt

3b. I highly recommend making a backup copy of the extracted ISO folder and the given
FE10Data.cms.decompressed file before you randomize so you don't have to redo steps 2-3
every time you want to use the randomizer. Make sure this backup is stored in a different
folder; the only files you want in the extracted ISO directory are files to be compressed
back into the ISO in the final step

4. Open up the randomizer and press the "Load Folder" button. This opens up a folder
viewer. You want to select the DATA/files folder inside your extracted ISO. Select
any parameters you want to randomize, and press the "Randomize" button to finish!
NOTE: The deviation in growths is a deviation from their current growths, so if you
randomize the same file more than once, the growths may get out of hand quickly. This
is why I recommend to make a copy in step 3b and start from a non-randomized folder
each time you use the randomizer.

5a. Once the randomization is complete, you can look at the outputlog.csv file to check
everything that has changed. If you are happy with the changes, it's time to basically 
do all of these steps in reverse.

5b. Compress FE10Data.cms.decompressed using BatchLZ77, found in the "tools" folder of the
randomizer. It will save the file as FE10Data.cms.decompressed.compressed - delete the added 
part so that the file is named FE10Data.cms (overwriting the original). Delete FE10Data.cms.decompressed
from the DATA/files directory

5c. Use WiiBaFu's "Transfer to Image" function to compress the extracted files into a
new ISO. Congrats, you have a randomized copy of FE10!

6. Enjoy your randomized experience. Note that the randomizer only work on normal and
hard difficulties. Please inform me of any bugs you find, or ask questions if you are 
confused on any of the steps in this readme. You can contact me on discord
(LordMewtwo73#2271) or reddit (LordMewtwo73)


Thank you to all that have contributed to figuring out how to hack Radiant Dawn, notably
VincentASM and Missing-qry, whose information on Radiant Dawn was the only reason I was
able to do this in the first place.
[https://forums.serenesforest.net/index.php?/topic/18280-fe10-radiant-dawn-hacking-notes/]

HUGE thank you to all of the great people who joined my discord server and helped me find all
of the bugs in the first iterations of this randomizer. You guys are the reason this turned out
to be so great!
